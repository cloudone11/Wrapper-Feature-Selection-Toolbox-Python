# MultiObjective GWO Feature Extraction

This project was a part of my course in 6th term at MAIT. 
The repository includes a modified version of MATLAB source code of MOGWO provided by S. Mirjalili et. al.  The MOGWO algorithm is used to implement feature selection using a threshold based
binarizing method. 
