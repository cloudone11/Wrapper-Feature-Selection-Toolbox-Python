# Grey-Wolf-Equilibrium-Optimiser
We propose an improved grey wolf equilibrium optimizer (GWEO) that integrates the search mechanisms of grey wolf optimization (GWO) and equilibrium optimizer (EO). A disturbance component of EO involves in the search mechanism of GWO to relieve the diversity problem.
