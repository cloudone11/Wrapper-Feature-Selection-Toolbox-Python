# Hybrid-GWOPSO-optimization
This script implements the hybrid of PSO and GWO optimization algorithm.

The hybrid Particle Swarm Optimization and Grey Wolf Optimization algorithm is low level because we merge the functionalities of both of them. Both the algorithms  run in parallel.
![Hybrid GWOPSO comparison](https://github.com/earthat/Hybrid-GWOPSO-optimization/blob/master/result/PSOGWO.png)

The details of this algorithm can be checked at https://free-thesis.com/product/hybrid-particle-swarm-and-grey-wolf-optimization/
