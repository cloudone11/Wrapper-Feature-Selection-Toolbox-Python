# Python implementation of Gray Wolf Optimizer and Improved Gray Wolf Optimizer
#### Both implementations minimize the sphere function to its optimal solution.
![image](https://user-images.githubusercontent.com/59822382/121601169-2f2f1d80-ca0b-11eb-8f51-5b6c98272ce2.png)

#### References: https://www.sciencedirect.com/science/article/abs/pii/S0957417420307107.

